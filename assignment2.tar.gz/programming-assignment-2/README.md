# Programming assignment 2

Main method idea:
    For n:
        Read in line from input file
        Create object for that line
        That object should auto calculate everything
        Ouptut to output file