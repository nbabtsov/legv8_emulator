javac -sourcepath ~/programming-assignment-2/src ~/programming-assignment-2/src/Main.java
