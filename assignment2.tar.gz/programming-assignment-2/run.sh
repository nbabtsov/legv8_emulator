java -classpath ~/programming-assignment-2/src Main $1
