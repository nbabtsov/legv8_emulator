public class IMTypeInstruction extends Instruction
{
    public IMTypeInstruction(String bitcode) {
        super(bitcode);
    }
}
